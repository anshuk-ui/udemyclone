import css from "./CreateCourse.module.css";
const CreateCourse = () => {
  return <div>CreateCourse</div>;
};

export default CreateCourse;
