import css from "./StepFourComp.module.css";
const StepFourComp = () => {
  return <div>StepFourComp</div>;
};

export default StepFourComp;
