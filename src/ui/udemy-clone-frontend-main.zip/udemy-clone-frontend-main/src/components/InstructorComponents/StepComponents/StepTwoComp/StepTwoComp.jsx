import css from "./StepTwoComp.module.css";
const StepTwoComp = () => {
  return <div>StepTwoComp</div>;
};

export default StepTwoComp;
